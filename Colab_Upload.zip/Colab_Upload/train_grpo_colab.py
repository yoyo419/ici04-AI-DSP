#!/usr/bin/env python3
"""
🌩️ Google Colab 专用 GRPO 训练脚本
适用于 Qwen2.5 Legal Delta 模型的强化学习训练

特点：
- 使用 GRPO (Generative Reinforcement Learning from Policy Optimization)
- 完全在 Colab Linux 环境运行
- 不依赖 conda（使用 pip）
- 自动下载模型
- 支持 GPU 加速
- 包含奖励函数（XML 格式 + 法律任务评分）

安装依赖（在运行此脚本前执行）：
    # 基础依赖
    !pip install -q transformers peft datasets trl bitsandbytes accelerate
    
    # Unsloth（必需，用于 GRPO 加速）
    !pip install -q "unsloth[colab-new] @ git+https://github.com/unslothai/unsloth.git"
    
    # 或使用 PyPI 版本（推荐）
    !pip install -q unsloth --upgrade
"""

import os
import sys
import time
from datetime import datetime

# 抑制 TensorFlow/CUDA 警告（Colab 环境常见）
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '3'
os.environ['TF_ENABLE_ONEDNN_OPTS'] = '0'
import warnings
warnings.filterwarnings('ignore', category=FutureWarning)
warnings.filterwarnings('ignore', category=UserWarning)

# Unsloth 环境变量
os.environ["CUDA_VISIBLE_DEVICES"] = "0"
os.environ["UNSLOTH_COMPILE_OVERWRITE"] = "0"
os.environ["UNSLOTH_CACHE_DIR"] = "/content/Colab/scripts/unsloth_compiled_cache"

import torch._dynamo
import torch
from datasets import load_dataset, Dataset
from unsloth import FastLanguageModel, PatchFastRL, is_bfloat16_supported
PatchFastRL("GRPO", FastLanguageModel)
from trl import GRPOConfig, GRPOTrainer
import swanlab
# 导入奖励函数
from reward import enhanced_scoring_function_v2, xmlcount_reward_func

torch._dynamo.config.suppress_errors = True
torch._dynamo.config.disable = True

# ============================================================
# 环境设定
# ============================================================
print("=" * 70)
print("🌩️ LegalDelta GRPO Colab 训练脚本")
print("=" * 70)
print()

# 检查是否在 Colab 环境
IN_COLAB = False
try:
    import google.colab
    IN_COLAB = True
except ImportError:
    if 'COLAB_GPU' in os.environ or 'COLAB_TPU_ADDR' in os.environ:
        IN_COLAB = True
    elif os.path.exists('/content') and os.path.exists('/usr/local/lib/python3.10/dist-packages'):
        IN_COLAB = True

if IN_COLAB:
    print("✓ 在 Google Colab 环境中")
else:
    print("⚠️  不在 Colab 环境（本地测试模式）")

print()

# 检查 GPU
if not torch.cuda.is_available():
    print("❌ 未检测到 GPU。GRPO 训练需要 GPU！")
    print("请在 Colab 中启用 GPU：Runtime -> Change runtime type -> Hardware accelerator -> GPU")
    sys.exit(1)
else:
    print(f"✓ GPU: {torch.cuda.get_device_name(0)}")
    print(f"✓ GPU 记忆体: {torch.cuda.get_device_properties(0).total_memory / 1e9:.2f} GB")

print()

# ============================================================
# 超参数配置
# ============================================================
class Config:
    # 模型设定
    model_size = "7B"  # 可改为 "14B" 但需要更多记忆体
    base_model_name = f"Qwen/Qwen2.5-{model_size}-Instruct"
    base_model_path = f"/content/Colab/Qwen2.5-{model_size}-Instruct"
    
    # 训练数据
    train_data = "/content/Colab_Upload/data/training_data.json"
    dev_data = "/content/Colab_Upload/data/vaid_data.json"
    
    # 输出路径
    output_dir = "/content/Colab/outputs"
    lora_output = "/content/Colab/lora_adapter_grpo"
    log_dir = "/content/Colab/logs"
    
    # LoRA 配置
    lora_rank = 32
    lora_alpha = 32
    target_modules = ["q_proj", "k_proj", "v_proj", "o_proj", 
                     "gate_proj", "up_proj", "down_proj"]
    
    # 训练超参数
    learning_rate = 5e-5
    num_train_epochs = 3  # Colab 时间有限，减少 epochs
    per_device_batch_size = 1  # 降低以配合 fp16（不使用 4bit 量化）
    gradient_accumulation_steps = 8  # 增加梯度累积以补偿小 batch
    max_seq_length = 1200
    per_device_eval_batch_size = 8  # 与训练 batch size 保持一致
    
    # GRPO 特定参数
    num_generations = 4  # 每个 prompt 生成的回复数（2*4=8，容易分解）
    max_prompt_length = 400
    max_completion_length = 250
    
    # 其他设定
    save_steps = 100
    logging_steps = 1
    save_total_limit = 2
    
    # 优化器
    optim = "paged_adamw_8bit"
    warmup_ratio = 0.1
    lr_scheduler_type = "cosine"
    max_grad_norm = 0.1

config = Config()

# 创建必要目录
os.makedirs(config.output_dir, exist_ok=True)
os.makedirs(config.log_dir, exist_ok=True)
os.makedirs(config.lora_output, exist_ok=True)
os.makedirs(os.path.dirname(os.environ["UNSLOTH_CACHE_DIR"]), exist_ok=True)

# 设定日志
experiment_name = f"qwen{config.model_size}_grpo_colab_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
log_file = os.path.join(config.log_dir, f"{experiment_name}.log")

def log_print(message):
    """同时输出到控制台和日志档案"""
    print(message)
    with open(log_file, "a", encoding="utf-8") as f:
        f.write(f"[{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}] {message}\n")

log_print(f"实验名称: {experiment_name}")
log_print(f"日志档案: {log_file}")
log_print("")

swanlab.init(
    project="GRPO_training", 
    name=experiment_name,
    config={
        "model": config.model_size,
        "lora_rank": config.lora_rank,
        "learning_rate": config.learning_rate,
        "max_steps": config.save_steps,
        "batch_size": config.per_device_batch_size,
    },
    settings=swanlab.Settings(init_timeout=120)
)

# ============================================================
# 1. 检查/下载基础模型
# ============================================================
log_print("=" * 70)
log_print("步骤 1: 检查基础模型")
log_print("=" * 70)

if not os.path.exists(config.base_model_path):
    log_print(f"⬇️  下载模型: {config.base_model_name}")
    log_print("这可能需要 5-15 分钟...")
    
    from huggingface_hub import snapshot_download
    
    try:
        model_path = snapshot_download(
            repo_id=config.base_model_name,
            local_dir=config.base_model_path,
            local_dir_use_symlinks=False,
            resume_download=True
        )
        log_print(f"✓ 模型下载完成: {model_path}")
    except Exception as e:
        log_print(f"❌ 模型下载失败: {e}")
        sys.exit(1)
else:
    log_print(f"✓ 模型已存在: {config.base_model_path}")

log_print("")

# ============================================================
# 2. 载入模型和 Tokenizer（使用 Unsloth）
# ============================================================
log_print("=" * 70)
log_print("步骤 2: 载入模型（Unsloth FastLanguageModel）")
log_print("=" * 70)

try:
    model, tokenizer = FastLanguageModel.from_pretrained(
        model_name=config.base_model_path,
        max_seq_length=config.max_seq_length,
        dtype=None,  # 自动选择 dtype (bf16/fp16)
        load_in_4bit=False,  # ❌ GRPO 不能使用 4bit 量化（会导致 InferenceMode 错误）
        # fast_inference=True,  # ❌ 移除此选项，GRPO 需要动态切换训练/推理模式
        max_lora_rank=config.lora_rank,
    )
    log_print("✓ 模型载入完成（Unsloth，使用 fp16/bf16）")
    
    # 确保 tokenizer 有 pad_token（GRPO 训练需要）
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token
        log_print("✓ 设置 pad_token = eos_token")
    
except Exception as e:
    log_print(f"❌ 模型载入失败: {e}")
    sys.exit(1)

log_print("")

# ============================================================
# 3. 配置 LoRA（使用 Unsloth）
# ============================================================
log_print("=" * 70)
log_print("步骤 3: 配置 LoRA（Unsloth）")
log_print("=" * 70)

model = FastLanguageModel.get_peft_model(
    model,
    r=config.lora_rank,
    lora_alpha=config.lora_alpha,
    target_modules=config.target_modules,
    use_gradient_checkpointing="unsloth",
    random_state=3407,
)

log_print("✓ LoRA 配置完成")

# 確保模型處於訓練模式（GRPO 需要）
FastLanguageModel.for_training(model)
log_print("✓ 模型已設置為訓練模式")
log_print("")

# ============================================================
# 4. 准备数据集（GRPO 格式）
# ============================================================
log_print("=" * 70)
log_print("步骤 4: 准备数据集（GRPO 格式）")
log_print("=" * 70)

from datasets import Dataset

# System prompts
SYSTEM_PROMPT = """用户与助手之间的对话。用户提出问题，助手解决它。助手首先思考推理过程，然后提供用户答案。推理过程和答案分别包含在 <reasoning> </reasoning> 和 <answer> </answer> 标签中。

请按照以下格式回答问题：
<reasoning>
在此详细分析问题并展示完整的推理过程，包括思考步骤、相关知识和逻辑分析。
</reasoning>
<answer>
在此提供简洁明确的最终答案(回答至少一個選項，回答至少一個選項，注意，如果答案不只一個選項，如12345，一定要輸出(12345)，不要輸出(1)(2)(3)(4)(5))。
</answer>"""

SYSTEM_PROMPT_BASE = """用户与助手之间的对话。用户提出问题，助手解决它。答案包含在 <answer> </answer> 标签中。

请按照以下格式回答问题：
<answer>
在此提供简洁明确的最终答案(回答至少一個選項，回答至少一個選項，注意，如果答案不只一個選項，如12345，一定要輸出(12345)，不要輸出(1)(2)(3)(4)(5))。
</answer>"""

def get_questions(split: str = "train") -> Dataset:
    if split == "train":
        file_path = "/content/Colab_Upload/data/training_data.json"
    elif split == "valid":
        file_path = "/content/Colab_Upload/data/valid_data.json"
    elif split == "test":
        file_path = "/content/Colab_Upload/data/test_data.json"
    else:
        raise ValueError(f"Invalid split: {split}. Must be 'train' or 'valid'.")
    
    # Check if file exists, if not try local path
    if not os.path.exists(file_path):
        local_path = file_path.replace("/content/Colab_Upload/", "../")
        if os.path.exists(local_path):
            file_path = local_path
            log_print(f"使用本地路徑: {file_path}")
        else:
            raise FileNotFoundError(f"找不到資料檔案: {file_path}")
    
    log_print(f"載入資料集: {file_path}")
    data = load_dataset("json", data_files=file_path) 
    data = data['train']  
    
    log_print(f"原始資料集大小: {len(data)}")
    
    EXAMPLE_TEXT = """
    你是一个職業安全衛生專家，请按照以下要求回答：
     """
    
    def process_sample(x: dict) -> dict:
        """Process a single sample from the dataset."""
        return { 
            'prompt': [
                {'role': 'system', 'content': SYSTEM_PROMPT},
                {'role': 'user', 'content': f"[QUERY_ID:{x['id']}]\n" + f"[QUERY_SOURCE:{x['source']}]\n" + EXAMPLE_TEXT + x['instruction'] + x['question']}
            ],
            'prompt_base': [
                {'role': 'system', 'content': SYSTEM_PROMPT_BASE},
                {'role': 'user', 'content': f"[QUERY_ID:{x['id']}]\n" + f"[QUERY_SOURCE:{x['source']}]\n" + EXAMPLE_TEXT + x['instruction_base'] + x['question']},
                {'role': 'assistant', 'content': f"<answer>\n{x['answer']}\n</answer>"}
            ],
            'answer': x['answer'],
            'id': x['id'] 
        }
    
    data = data.map(process_sample)
    log_print(f"處理後資料集大小: {len(data)}")

    return data


train_dataset = get_questions(split="train")
val_dataset = get_questions(split="valid")

# ============================================================
# 5. 设定训练参数（GRPO）
# ============================================================
log_print("=" * 70)
log_print("步骤 5: 配置 GRPO 训练")
log_print("=" * 70)

training_args = GRPOConfig(
    use_vllm=False,  # ✅ 使用 HuggingFace generate（Colab 環境推薦）
    learning_rate=config.learning_rate,
    lr_scheduler_type=config.lr_scheduler_type,
    optim=config.optim,
    logging_steps=config.logging_steps,
    bf16 = is_bfloat16_supported(),
    fp16 = not is_bfloat16_supported(),
    per_device_train_batch_size=config.per_device_batch_size,
    gradient_accumulation_steps=config.gradient_accumulation_steps,
    num_generations=config.num_generations,  
    per_device_eval_batch_size=config.per_device_eval_batch_size,
    max_prompt_length=config.max_prompt_length,
    max_completion_length=config.max_completion_length,
    num_train_epochs=config.num_train_epochs, 
    eval_strategy="epoch",
    save_strategy="epoch",
    do_eval=True,
    logging_strategy="steps",
    log_level="info",  
    max_grad_norm=config.max_grad_norm,
    report_to="tensorboard",
    output_dir=config.output_dir,
    local_rank=-1,
    deepspeed=None,
)

log_print("✓ GRPO 配置完成")
log_print("")
log_print("训练配置:")
log_print(f"  - Epochs: {config.num_train_epochs}")
log_print(f"  - Batch size: {config.per_device_batch_size}")
log_print(f"  - Gradient accumulation: {config.gradient_accumulation_steps}")
log_print(f"  - Effective batch size: {config.per_device_batch_size * config.gradient_accumulation_steps}")
log_print(f"  - Learning rate: {config.learning_rate}")
log_print(f"  - Num generations: {config.num_generations}")
log_print("")

# ============================================================
# 6. 定义评估 Callback（额外指标）
# ============================================================
from transformers import TrainerCallback
import numpy as np

class TokenLevelMetricsCallback(TrainerCallback):
    
    def __init__(self, tokenizer):
        self.tokenizer = tokenizer
        self.eval_count = 0
    
    def on_evaluate(self, args, state, control, model, metrics=None, **kwargs):
        """在评估结束时调用，计算额外的指标"""
        if metrics is None:
            return
        
        self.eval_count += 1
        
        log_print("")
        log_print("=" * 70)
        log_print(f"📊 评估 #{self.eval_count} - GRPO Reward 指标（来自 reward_funcs）:")
        log_print("=" * 70)
        
        # 显示 GRPO 的 reward 指标
        reward_metrics = {}
        other_metrics = {}
        
        for key, value in sorted(metrics.items()):
            if 'reward' in key.lower():
                reward_metrics[key] = value
            else:
                other_metrics[key] = value
        
        # 显示奖励指标
        if reward_metrics:
            log_print("  奖励函数指标:")
            for key, value in reward_metrics.items():
                if isinstance(value, (int, float)):
                    log_print(f"    {key}: {value:.6f}")
                else:
                    log_print(f"    {key}: {value}")
        
        # 显示其他指标
        if other_metrics:
            log_print("  其他指标:")
            for key, value in other_metrics.items():
                if isinstance(value, (int, float)):
                    log_print(f"    {key}: {value:.6f}")
                else:
                    log_print(f"    {key}: {value}")
        
        log_print("=" * 70)
        log_print("")

# ============================================================
# 6.5 創建生成樣本展示 Callback（顯示預測答案 vs 真實答案）
# ============================================================
class GenerationSamplesCallback(TrainerCallback):
    """
    在評估時生成並顯示樣本預測答案
    
    功能：
    - 從驗證集隨機抽取樣本
    - 生成模型預測答案
    - 顯示真實答案
    - 計算並顯示該樣本的 reward 分數
    """
    
    def __init__(self, tokenizer, eval_dataset, num_samples=3):
        self.tokenizer = tokenizer
        self.eval_dataset = eval_dataset
        self.num_samples = num_samples
        self.eval_count = 0
    
    def on_evaluate(self, args, state, control, model, metrics=None, **kwargs):
        """在評估時生成並顯示樣本"""
        self.eval_count += 1
        
        log_print("")
        log_print("=" * 70)
        log_print(f"📝 評估 #{self.eval_count} - 生成樣本展示 (共 {self.num_samples} 個樣本)")
        log_print("=" * 70)
        log_print("")
        
        # 從驗證集隨機抽取樣本
        import random
        import numpy as np
        
        indices = random.sample(range(len(self.eval_dataset)), min(self.num_samples, len(self.eval_dataset)))
        
        for idx_num, sample_idx in enumerate(indices, 1):
            sample = self.eval_dataset[sample_idx]
            
            log_print(f"【樣本 {idx_num}/{self.num_samples}】")
            log_print(f"  ID: {sample['id']}")
            log_print("")
            
            # 顯示問題（Prompt）
            prompt_text = sample['prompt'][1]['content']  # user message
            log_print(f"  📋 問題:")
            log_print(f"    {prompt_text[:200]}..." if len(prompt_text) > 200 else f"    {prompt_text}")
            log_print("")
            
            # 使用模型生成預測答案
            try:
                # 準備輸入
                messages = sample['prompt']
                input_text = self.tokenizer.apply_chat_template(
                    messages,
                    tokenize=False,
                    add_generation_prompt=True
                )
                
                inputs = self.tokenizer(input_text, return_tensors="pt").to(model.device)
                
                # 生成
                with torch.no_grad():
                    outputs = model.generate(
                        **inputs,
                        max_new_tokens=512,
                        temperature=0.7,
                        do_sample=True,
                        pad_token_id=self.tokenizer.pad_token_id,
                        eos_token_id=self.tokenizer.eos_token_id,
                    )
                
                # 解碼預測答案
                generated_ids = outputs[0][inputs['input_ids'].shape[1]:]
                predicted_answer = self.tokenizer.decode(generated_ids, skip_special_tokens=True)
                
                log_print(f"  🤖 模型預測答案:")
                log_print(f"    {predicted_answer[:500]}..." if len(predicted_answer) > 500 else f"    {predicted_answer}")
                log_print("")
                
                # 顯示真實答案
                true_answer = sample['answer']
                log_print(f"  ✅ 真實答案:")
                log_print(f"    {true_answer[:500]}..." if len(true_answer) > 500 else f"    {true_answer}")
                log_print("")
                
                # 計算 reward（使用訓練時的 reward 函數）
                try:
                    # 準備 reward 函數需要的格式
                    prompt_list = [sample['prompt']]
                    generated_list = [predicted_answer]
                    
                    # 計算 XML 完整性獎勵
                    xml_reward = xmlcount_reward_func(generated_list)
                    
                    # 計算內容評分獎勵
                    content_reward = enhanced_scoring_function_v2(prompt_list, generated_list)
                    
                    log_print(f"  📊 該樣本評分:")
                    log_print(f"    - XML 完整性: {xml_reward[0]:.4f}")
                    log_print(f"    - 內容評分: {content_reward[0]:.4f}")
                    log_print(f"    - 平均獎勵: {(xml_reward[0] + content_reward[0]) / 2:.4f}")
                except Exception as e:
                    log_print(f"  ⚠️  無法計算 reward: {e}")
                
            except Exception as e:
                log_print(f"  ❌ 生成失敗: {e}")
            
            log_print("")
            log_print("-" * 70)
            log_print("")
        
        log_print("=" * 70)
        log_print("")

# 創建兩個 callback
log_print("創建評估 Callbacks...")
metrics_callback = TokenLevelMetricsCallback(tokenizer=tokenizer)
generation_callback = GenerationSamplesCallback(
    tokenizer=tokenizer, 
    eval_dataset=val_dataset,
    num_samples=3  # 每次評估顯示 3 個樣本
)
log_print("✓ Callbacks 創建完成")
log_print("  - TokenLevelMetricsCallback: 顯示評估指標")
log_print("  - GenerationSamplesCallback: 顯示預測答案 vs 真實答案")
log_print("")

# ============================================================
# 7. 创建 GRPO Trainer
# ============================================================
log_print("=" * 70)
log_print("步骤 7: 创建 GRPO Trainer")
log_print("=" * 70)

trainer = GRPOTrainer(
    model=model,
    processing_class=tokenizer,
    reward_funcs=[xmlcount_reward_func, enhanced_scoring_function_v2],
    args=training_args,
    train_dataset=train_dataset,
    eval_dataset=val_dataset,
    callbacks=[metrics_callback, generation_callback],  # 添加兩個评估 callbacks
)

log_print("✓ GRPO Trainer 创建完成")
log_print("")
log_print("奖励函数:")
log_print("  1. xmlcount_reward_func - XML 标签完整性检查")
log_print("  2. enhanced_scoring_function_v2 - 法律任务内容评分")
log_print("")

# ============================================================
# 8. 开始训练
# ============================================================
log_print("=" * 70)
log_print("步骤 8: 开始训练")
log_print("=" * 70)
log_print("")

start_time = time.time()

try:
    log_print("🚀 GRPO 训练开始...")
    log_print("")
    
    # 训练
    train_result = trainer.train()
    
    # 记录训练结果到日志
    log_print("")
    log_print("=" * 70)
    log_print("📊 训练结果：")
    log_print("=" * 70)
    if hasattr(train_result, 'metrics'):
        for key, value in sorted(train_result.metrics.items()):
            if isinstance(value, (int, float)):
                log_print(f"  {key}: {value:.6f}")
            else:
                log_print(f"  {key}: {value}")
    log_print("=" * 70)
    
    # 保存最终模型
    log_print("")
    log_print("=" * 70)
    log_print("保存模型...")
    
    trainer.save_model(config.lora_output)
    tokenizer.save_pretrained(config.lora_output)
    
    elapsed = time.time() - start_time
    hours = int(elapsed // 3600)
    minutes = int((elapsed % 3600) // 60)
    seconds = int(elapsed % 60)
    
    log_print(f"✓ 训练完成！")
    log_print(f"✓ 训练时间: {hours} 小时 {minutes} 分钟 {seconds} 秒")
    log_print(f"✓ LoRA adapter 已保存到: {config.lora_output}")
    log_print("=" * 70)
    
    # 如果在 Colab，保存到 Google Drive
    if IN_COLAB:
        log_print("")
        log_print("尝试保存到 Google Drive...")
        
        try:
            from google.colab import drive
            import shutil
            
            # 检查 Drive 是否已挂载
            if not os.path.exists('/content/drive'):
                drive.mount('/content/drive')
            
            # 保存路径
            save_base = f'/content/drive/MyDrive/LegalDelta_GRPO_Results/{experiment_name}'
            os.makedirs(save_base, exist_ok=True)
            
            # 复制 LoRA adapter
            shutil.copytree(config.lora_output, f'{save_base}/lora_adapter')
            
            # 复制日志
            if os.path.exists(log_file):
                shutil.copy(log_file, f'{save_base}/')
            
            # 复制 TensorBoard logs
            if os.path.exists(os.path.join(config.output_dir, experiment_name)):
                shutil.copytree(
                    os.path.join(config.output_dir, experiment_name),
                    f'{save_base}/tensorboard_logs',
                    dirs_exist_ok=True
                )
            
            log_print(f"✓ 已备份到 Google Drive: {save_base}")
        except Exception as e:
            log_print(f"⚠️  备份到 Drive 失败: {e}")
            log_print("  训练结果仍保存在 Colab 临时储存中")

    print("\n🎉 SUCCESS! GRPO 训练完成!")
    print(f"📁 LoRA adapter 保存到: {config.lora_output}")
    print(f"⏱️  总时间: {hours} 小时 {minutes} 分钟 {seconds} 秒")
    swanlab.finish()

except KeyboardInterrupt:
    log_print("\n⚠️  训练被用户中断")
    print("\n训练中断。部分结果可能已保存在 checkpoints。")

except Exception as e:
    log_print(f"\n❌ 训练失败: {e}")
    import traceback
    log_print(traceback.format_exc())
    raise

finally:
    # 清理记忆体
    import gc
    gc.collect()
    if torch.cuda.is_available():
        torch.cuda.empty_cache()
    log_print("✓ 记忆体清理完成。")

