#!/usr/bin/env python3
"""
🌩️ Google Colab 专用 GRPO 训练脚本
适用于 Qwen2.5 Legal Delta 模型的强化学习训练

特点：
- 使用 GRPO (Generative Reinforcement Learning from Policy Optimization)
- 完全在 Colab Linux 环境运行
- 不依赖 conda（使用 pip）
- 自动下载模型
- 支持 GPU 加速
- 包含奖励函数（XML 格式 + 法律任务评分）

安装依赖（在运行此脚本前执行）：
    # 基础依赖
    !pip install -q transformers peft datasets trl bitsandbytes accelerate
    
    # Unsloth（必需，用于 GRPO 加速）
    !pip install -q "unsloth[colab-new] @ git+https://github.com/unslothai/unsloth.git"
    
    # 或使用 PyPI 版本（推荐）
    !pip install -q unsloth --upgrade
"""

import os
import sys
import time
from datetime import datetime

# 抑制 TensorFlow/CUDA 警告（Colab 环境常见）
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '3'
os.environ['TF_ENABLE_ONEDNN_OPTS'] = '0'
import warnings
warnings.filterwarnings('ignore', category=FutureWarning)
warnings.filterwarnings('ignore', category=UserWarning)

# Unsloth 环境变量
os.environ["CUDA_VISIBLE_DEVICES"] = "0"
os.environ["UNSLOTH_COMPILE_OVERWRITE"] = "0"
os.environ["UNSLOTH_CACHE_DIR"] = "/content/Colab/scripts/unsloth_compiled_cache"

import torch._dynamo
import torch
from datasets import load_dataset, Dataset
from unsloth import FastLanguageModel, PatchFastRL, is_bfloat16_supported
PatchFastRL("GRPO", FastLanguageModel)
from trl import GRPOConfig, GRPOTrainer

# 导入奖励函数
from reward_colab import enhanced_scoring_function_v2, xmlcount_reward_func

torch._dynamo.config.suppress_errors = True
torch._dynamo.config.disable = True

# ============================================================
# 环境设定
# ============================================================
print("=" * 70)
print("🌩️ LegalDelta GRPO Colab 训练脚本")
print("=" * 70)
print()

# 检查是否在 Colab 环境
IN_COLAB = False
try:
    import google.colab
    IN_COLAB = True
except ImportError:
    if 'COLAB_GPU' in os.environ or 'COLAB_TPU_ADDR' in os.environ:
        IN_COLAB = True
    elif os.path.exists('/content') and os.path.exists('/usr/local/lib/python3.10/dist-packages'):
        IN_COLAB = True

if IN_COLAB:
    print("✓ 在 Google Colab 环境中")
else:
    print("⚠️  不在 Colab 环境（本地测试模式）")

print()

# 固定随机种子
def set_seed(seed=3407):
    import random
    import numpy as np
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)

set_seed(3407)

# 检查 GPU
if not torch.cuda.is_available():
    print("❌ 未检测到 GPU。GRPO 训练需要 GPU！")
    print("请在 Colab 中启用 GPU：Runtime -> Change runtime type -> Hardware accelerator -> GPU")
    sys.exit(1)
else:
    print(f"✓ GPU: {torch.cuda.get_device_name(0)}")
    print(f"✓ GPU 记忆体: {torch.cuda.get_device_properties(0).total_memory / 1e9:.2f} GB")

print()

# ============================================================
# 超参数配置
# ============================================================
class Config:
    # 模型设定
    model_size = "3B"  # 可改为 "14B" 但需要更多记忆体
    base_model_name = f"Qwen/Qwen2.5-{model_size}-Instruct"
    base_model_path = f"/content/Colab/Qwen2.5-{model_size}-Instruct"
    
    # 训练数据
    train_data = "/content/Colab_Upload/data/GRPO_training.json"
    dev_data = "/content/Colab_Upload/data/GRPO_dev.json"
    
    # 输出路径
    output_dir = "/content/Colab/outputs"
    lora_output = "/content/Colab/lora_adapter_grpo"
    log_dir = "/content/Colab/logs"
    
    # LoRA 配置
    lora_rank = 32
    lora_alpha = 32
    target_modules = ["q_proj", "k_proj", "v_proj", "o_proj", 
                     "gate_proj", "up_proj", "down_proj"]
    
    # 训练超参数
    learning_rate = 5e-5
    num_train_epochs = 3  # Colab 时间有限，减少 epochs
    per_device_batch_size = 1
    gradient_accumulation_steps = 32
    max_seq_length = 8192
    
    # GRPO 特定参数
    num_generations = 4  # 每个 prompt 生成的回复数
    max_prompt_length = 4096
    max_completion_length = 512
    
    # 其他设定
    save_steps = 100
    logging_steps = 1
    save_total_limit = 2
    
    # 优化器
    optim = "paged_adamw_8bit"
    warmup_ratio = 0.1
    lr_scheduler_type = "cosine"
    max_grad_norm = 0.1

config = Config()

# 创建必要目录
os.makedirs(config.output_dir, exist_ok=True)
os.makedirs(config.log_dir, exist_ok=True)
os.makedirs(config.lora_output, exist_ok=True)
os.makedirs(os.path.dirname(os.environ["UNSLOTH_CACHE_DIR"]), exist_ok=True)

# 设定日志
experiment_name = f"qwen{config.model_size}_grpo_colab_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
log_file = os.path.join(config.log_dir, f"{experiment_name}.log")

def log_print(message):
    """同时输出到控制台和日志档案"""
    print(message)
    with open(log_file, "a", encoding="utf-8") as f:
        f.write(f"[{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}] {message}\n")

log_print(f"实验名称: {experiment_name}")
log_print(f"日志档案: {log_file}")
log_print("")

# ============================================================
# 1. 检查/下载基础模型
# ============================================================
log_print("=" * 70)
log_print("步骤 1: 检查基础模型")
log_print("=" * 70)

if not os.path.exists(config.base_model_path):
    log_print(f"⬇️  下载模型: {config.base_model_name}")
    log_print("这可能需要 5-15 分钟...")
    
    from huggingface_hub import snapshot_download
    
    try:
        model_path = snapshot_download(
            repo_id=config.base_model_name,
            local_dir=config.base_model_path,
            local_dir_use_symlinks=False,
            resume_download=True
        )
        log_print(f"✓ 模型下载完成: {model_path}")
    except Exception as e:
        log_print(f"❌ 模型下载失败: {e}")
        sys.exit(1)
else:
    log_print(f"✓ 模型已存在: {config.base_model_path}")

log_print("")

# ============================================================
# 2. 载入模型和 Tokenizer（使用 Unsloth）
# ============================================================
log_print("=" * 70)
log_print("步骤 2: 载入模型（Unsloth FastLanguageModel）")
log_print("=" * 70)

try:
    model, tokenizer = FastLanguageModel.from_pretrained(
        model_name=config.base_model_path,
        max_seq_length=config.max_seq_length,
        load_in_4bit=False,  # GRPO 建议使用 float16 而非量化
        fast_inference=True,
        max_lora_rank=config.lora_rank,
        gpu_memory_utilization=0.7,
    )
    log_print("✓ 模型载入完成（Unsloth）")
    
    # 确保 tokenizer 有 pad_token（GRPO 训练需要）
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token
        log_print("✓ 设置 pad_token = eos_token")
    
except Exception as e:
    log_print(f"❌ 模型载入失败: {e}")
    sys.exit(1)

log_print("")

# ============================================================
# 3. 配置 LoRA（使用 Unsloth）
# ============================================================
log_print("=" * 70)
log_print("步骤 3: 配置 LoRA（Unsloth）")
log_print("=" * 70)

model = FastLanguageModel.get_peft_model(
    model,
    r=config.lora_rank,
    lora_alpha=config.lora_alpha,
    target_modules=config.target_modules,
    use_gradient_checkpointing="unsloth",
    random_state=3407,
)

log_print("✓ LoRA 配置完成")
log_print("")

# ============================================================
# 4. 准备数据集（GRPO 格式）
# ============================================================
log_print("=" * 70)
log_print("步骤 4: 准备数据集（GRPO 格式）")
log_print("=" * 70)

from datasets import Dataset

# System prompts
SYSTEM_PROMPT = """用户与助手之间的对话。用户提出问题，助手解决它。助手首先思考推理过程，然后提供用户答案。推理过程和答案分别包含在 <reasoning> </reasoning> 和 <answer> </answer> 标签中。

请按照以下格式回答问题：
<reasoning>
在此详细分析问题并展示完整的推理过程，包括思考步骤、相关知识和逻辑分析。
</reasoning>
<answer>
在此提供简洁明确的最终答案。
</answer>"""

SYSTEM_PROMPT_BASE = """用户与助手之间的对话。用户提出问题，助手解决它。答案包含在 <answer> </answer> 标签中。

请按照以下格式回答问题：
<answer>
在此提供简洁明确的最终答案。
</answer>"""

def format_dataset_for_grpo(data_path):
    """
    格式化数据集为 GRPO 格式
    GRPO 需要 'prompt' 和 'prompt_base' 两个欄位
    """
    if not os.path.exists(data_path):
        log_print(f"❌ 数据集档案不存在: {data_path}")
        sys.exit(1)
    
    log_print(f"载入数据集: {data_path}")
    data = load_dataset("json", data_files=data_path)['train']
    
    EXAMPLE_TEXT = "\n    你是一个法律专家，请按照以下要求回答：\n     "
    
    formatted_data = []
    for item in data:
        formatted_item = {
            # prompt: 用于生成，包含推理要求
            'prompt': [
                {'role': 'system', 'content': SYSTEM_PROMPT},
                {'role': 'user', 'content': f"[QUERY_ID:{item['id']}]\n" + EXAMPLE_TEXT + item['instruction'] + item['question']}
            ],
            # prompt_base: 基准回答，只包含答案
            'prompt_base': [
                {'role': 'system', 'content': SYSTEM_PROMPT_BASE},
                {'role': 'user', 'content': f"[QUERY_ID:{item['id']}]\n" + EXAMPLE_TEXT + item.get('instruction_base', item['instruction']) + item['question']},
                {'role': 'assistant', 'content': f"<answer>\n{item['answer']}\n</answer>"}
            ],
            'answer': item['answer'],
            'id': item['id']
        }
        formatted_data.append(formatted_item)
    
    return Dataset.from_list(formatted_data)

train_dataset = format_dataset_for_grpo(config.train_data)
log_print(f"✓ 训练集: {len(train_dataset)} 筆（GRPO 格式）")

if config.dev_data and os.path.exists(config.dev_data):
    eval_dataset = format_dataset_for_grpo(config.dev_data)
    log_print(f"✓ 验证集: {len(eval_dataset)} 筆（GRPO 格式）")
else:
    eval_dataset = None
    log_print("⚠️  未找到验证集，将跳过评估")

log_print("")

# ============================================================
# 5. 设定训练参数（GRPO）
# ============================================================
log_print("=" * 70)
log_print("步骤 5: 配置 GRPO 训练")
log_print("=" * 70)

training_args = GRPOConfig(
    # GRPO 特定参数
    use_vllm=False,
    num_generations=config.num_generations,
    max_prompt_length=config.max_prompt_length,
    max_completion_length=config.max_completion_length,
    
    # 训练基础参数
    output_dir=os.path.join(config.output_dir, experiment_name),
    num_train_epochs=config.num_train_epochs,
    per_device_train_batch_size=config.per_device_batch_size,
    per_device_eval_batch_size=config.num_generations,
    gradient_accumulation_steps=config.gradient_accumulation_steps,
    
    # 优化器参数
    learning_rate=config.learning_rate,
    adam_beta1=0.9,
    adam_beta2=0.99,
    weight_decay=0.1,
    warmup_ratio=config.warmup_ratio,
    lr_scheduler_type=config.lr_scheduler_type,
    optim=config.optim,
    max_grad_norm=config.max_grad_norm,
    
    # 记录与评估
    logging_steps=config.logging_steps,
    logging_strategy="steps",
    log_level="info",
    save_steps=config.save_steps,
    save_strategy="steps",
    save_total_limit=config.save_total_limit,
    eval_strategy="epoch" if eval_dataset else "no",
    do_eval=True if eval_dataset else False,
    
    # 精度设置
    fp16=torch.cuda.is_available() and not is_bfloat16_supported(),
    bf16=torch.cuda.is_available() and is_bfloat16_supported(),
    
    # TensorBoard
    report_to="tensorboard",
    
    # 其他
    local_rank=-1,
    deepspeed=None,
)

log_print("✓ GRPO 配置完成")
log_print("")
log_print("训练配置:")
log_print(f"  - Epochs: {config.num_train_epochs}")
log_print(f"  - Batch size: {config.per_device_batch_size}")
log_print(f"  - Gradient accumulation: {config.gradient_accumulation_steps}")
log_print(f"  - Effective batch size: {config.per_device_batch_size * config.gradient_accumulation_steps}")
log_print(f"  - Learning rate: {config.learning_rate}")
log_print(f"  - Num generations: {config.num_generations}")
log_print("")

# ============================================================
# 6. 创建 GRPO Trainer
# ============================================================
log_print("=" * 70)
log_print("步骤 6: 创建 GRPO Trainer")
log_print("=" * 70)

# 配置生成参数（非 vLLM 模式需要）
from transformers import GenerationConfig

generation_config = GenerationConfig(
    max_new_tokens=config.max_completion_length,
    temperature=0.7,
    top_p=0.9,
    do_sample=True,
    pad_token_id=tokenizer.pad_token_id,
    eos_token_id=tokenizer.eos_token_id,
)

log_print("✓ 生成配置创建完成")
log_print(f"  - Max new tokens: {config.max_completion_length}")
log_print(f"  - Temperature: 0.7")
log_print(f"  - Top-p: 0.9")
log_print("")

trainer = GRPOTrainer(
    model=model,
    processing_class=tokenizer,
    reward_funcs=[xmlcount_reward_func, enhanced_scoring_function_v2],
    args=training_args,
    train_dataset=train_dataset,
    eval_dataset=eval_dataset,
    generation_config=generation_config,  # 添加生成配置
)

log_print("✓ GRPO Trainer 创建完成")
log_print("")
log_print("奖励函数:")
log_print("  1. xmlcount_reward_func - XML 标签完整性检查")
log_print("  2. enhanced_scoring_function_v2 - 法律任务内容评分")
log_print("")

# ============================================================
# 7. 开始训练
# ============================================================
log_print("=" * 70)
log_print("步骤 7: 开始训练")
log_print("=" * 70)
log_print("")

start_time = time.time()

try:
    log_print("🚀 GRPO 训练开始...")
    log_print("")
    
    # 训练
    train_result = trainer.train()
    
    # 记录训练结果到日志
    log_print("")
    log_print("=" * 70)
    log_print("📊 训练结果：")
    log_print("=" * 70)
    if hasattr(train_result, 'metrics'):
        for key, value in sorted(train_result.metrics.items()):
            if isinstance(value, float):
                log_print(f"  {key}: {value:.6f}")
            else:
                log_print(f"  {key}: {value}")
    log_print("=" * 70)
    
    # 保存最终模型
    log_print("")
    log_print("=" * 70)
    log_print("保存模型...")
    
    trainer.save_model(config.lora_output)
    tokenizer.save_pretrained(config.lora_output)
    
    elapsed = time.time() - start_time
    hours = int(elapsed // 3600)
    minutes = int((elapsed % 3600) // 60)
    seconds = int(elapsed % 60)
    
    log_print(f"✓ 训练完成！")
    log_print(f"✓ 训练时间: {hours} 小时 {minutes} 分钟 {seconds} 秒")
    log_print(f"✓ LoRA adapter 已保存到: {config.lora_output}")
    log_print("=" * 70)
    
    # 如果在 Colab，保存到 Google Drive
    if IN_COLAB:
        log_print("")
        log_print("尝试保存到 Google Drive...")
        
        try:
            from google.colab import drive
            import shutil
            
            # 检查 Drive 是否已挂载
            if not os.path.exists('/content/drive'):
                drive.mount('/content/drive')
            
            # 保存路径
            save_base = f'/content/drive/MyDrive/LegalDelta_GRPO_Results/{experiment_name}'
            os.makedirs(save_base, exist_ok=True)
            
            # 复制 LoRA adapter
            shutil.copytree(config.lora_output, f'{save_base}/lora_adapter')
            
            # 复制日志
            if os.path.exists(log_file):
                shutil.copy(log_file, f'{save_base}/')
            
            # 复制 TensorBoard logs
            if os.path.exists(os.path.join(config.output_dir, experiment_name)):
                shutil.copytree(
                    os.path.join(config.output_dir, experiment_name),
                    f'{save_base}/tensorboard_logs',
                    dirs_exist_ok=True
                )
            
            log_print(f"✓ 已备份到 Google Drive: {save_base}")
        except Exception as e:
            log_print(f"⚠️  备份到 Drive 失败: {e}")
            log_print("  训练结果仍保存在 Colab 临时储存中")

    print("\n🎉 SUCCESS! GRPO 训练完成!")
    print(f"📁 LoRA adapter 保存到: {config.lora_output}")
    print(f"⏱️  总时间: {hours} 小时 {minutes} 分钟 {seconds} 秒")

except KeyboardInterrupt:
    log_print("\n⚠️  训练被用户中断")
    print("\n训练中断。部分结果可能已保存在 checkpoints。")

except Exception as e:
    log_print(f"\n❌ 训练失败: {e}")
    import traceback
    log_print(traceback.format_exc())
    raise

finally:
    # 清理记忆体
    import gc
    gc.collect()
    if torch.cuda.is_available():
        torch.cuda.empty_cache()
    log_print("✓ 记忆体清理完成。")

