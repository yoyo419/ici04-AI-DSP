#!/usr/bin/env python3
"""
🧪 GRPO 模型測試腳本
用於測試訓練好的模型在測試集上的表現

支持兩種模型格式：
    1. 合併模型（Merged Model）- 直接載入完整模型
    2. LoRA Adapter - 基礎模型 + adapter

使用方法：
    # 測試合併模型（推薦）
    python test_colab.py --lora_adapter /content/Colab_Download/merged_model
    
    # 測試 LoRA adapter
    python test_colab.py --base_model /path/to/base --lora_adapter /path/to/adapter
    
    # 限制測試樣本數
    python test_colab.py --num_samples 10
"""

import os
import sys
import argparse
from datetime import datetime
import torch
from datasets import load_dataset, Dataset
from unsloth import FastLanguageModel
from tqdm import tqdm
import json

# 抑制警告
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '3'
import warnings
warnings.filterwarnings('ignore')

# ============================================================
# 配置
# ============================================================
class TestConfig:
    # 模型路徑
    base_model_path = "/content/Colab/Qwen2.5-3B-Instruct"  # 基礎模型（僅在使用 LoRA adapter 時需要）
    lora_adapter_path = "/content/merged_model"  # 合併模型或 LoRA adapter 路徑
    
    # 輸出路徑
    output_dir = "/content/Colab/test_results"
    
    # 生成參數
    max_seq_length = 2048
    max_new_tokens = 512
    temperature = 0.7
    top_p = 0.9
    do_sample = True
    
    # 測試樣本數（設為 None 測試全部）
    num_test_samples = None

# ============================================================
# System Prompts（與訓練一致）
# ============================================================
SYSTEM_PROMPT = """用户与助手之间的对话。用户提出问题，助手解决它。助手首先思考推理过程，然后提供用户答案。推理过程和答案分别包含在 <reasoning> </reasoning> 和 <answer> </answer> 标签中。

请按照以下格式回答问题：
<reasoning>
在此详细分析问题并展示完整的推理过程，包括思考步骤、相关知识和逻辑分析。
</reasoning>
<answer>
在此提供简洁明确的最终答案(注意，如果答案不只一個選項，如12345，一定要輸出(12345)，不要輸出(1)(2)(3)(4)(5))。
</answer>"""

SYSTEM_PROMPT_BASE = """用户与助手之间的对话。用户提出问题，助手解决它。答案包含在 <answer> </answer> 标签中。

请按照以下格式回答问题：
<answer>
在此提供简洁明确的最终答案(注意，如果答案不只一個選項，如12345，一定要輸出(12345)，不要輸出(1)(2)(3)(4)(5))。
</answer>"""

EXAMPLE_TEXT = """
你是一个職業安全衛生專家，请按照以下要求回答：
 """

# ============================================================
# 數據載入函數
# ============================================================
def get_questions(split: str = "test") -> Dataset:
    """
    載入並處理測試數據集
    
    Args:
        split: 數據集分割 ("train", "valid", "test")
    
    Returns:
        Dataset: 處理後的數據集
    """
    # 確定文件路徑
    if split == "train":
        file_path = "/content/Colab_Upload/data/training_data.json"
    elif split == "valid":
        file_path = "/content/Colab_Upload/data/valid_data.json"
    elif split == "test":
        file_path = "/content/test_data.json"
    else:
        raise ValueError(f"Invalid split: {split}. Must be 'train', 'valid', or 'test'.")
    
    # 檢查文件是否存在，嘗試本地路徑
    if not os.path.exists(file_path):
        local_path = file_path.replace("/content/Colab_Upload/", "./")
        if os.path.exists(local_path):
            file_path = local_path
            print(f"✓ 使用本地路徑: {file_path}")
        else:
            raise FileNotFoundError(f"❌ 找不到資料檔案: {file_path}")
    
    print(f"📂 載入資料集: {file_path}")
    
    # 載入數據
    data = load_dataset("json", data_files=file_path)
    data = data['train']  # HuggingFace datasets 統一使用 'train' key
    
    print(f"✓ 原始資料集大小: {len(data)}")
    
    # 處理每個樣本
    def process_sample(x: dict) -> dict:
        """處理單個樣本，準備 prompt 格式"""
        return { 
            'prompt': [
                {'role': 'system', 'content': SYSTEM_PROMPT},
                {'role': 'user', 'content': f"[QUERY_ID:{x['id']}]\n[QUERY_SOURCE:{x.get('source', 'unknown')}]\n" + EXAMPLE_TEXT + x['instruction'] + x['question']}
            ],
            'answer': x['answer'],
            'id': x['id'],
            'question': x['question'],
            'instruction': x['instruction'],
            'source': x.get('source', 'unknown')
        }
    
    data = data.map(process_sample)
    print(f"✓ 處理後資料集大小: {len(data)}")
    
    return data

# ============================================================
# 日誌函數
# ============================================================
def log_print(message: str):
    """印出訊息到控制台"""
    print(message)

# ============================================================
# 主測試函數
# ============================================================
def test_model(config: TestConfig):
    """
    測試訓練好的模型
    
    Args:
        config: 測試配置
    """
    print("=" * 70)
    print("🧪 GRPO 模型測試腳本")
    print("=" * 70)
    print()
    
    # 創建輸出目錄
    os.makedirs(config.output_dir, exist_ok=True)
    
    # ============================================================
    # 1. 載入模型
    # ============================================================
    print("=" * 70)
    print("步驟 1: 載入模型")
    print("=" * 70)
    
    try:
        # 檢查模型路徑是否存在
        if not os.path.exists(config.lora_adapter_path):
            log_print(f"❌ 找不到模型路徑: {config.lora_adapter_path}")
            log_print("請確認路徑是否正確")
            sys.exit(1)
        
        # 檢查是否為合併模型（merged model）
        # 判斷規則：有 adapter_config.json = LoRA adapter，沒有 = 合併模型
        adapter_config_file = os.path.join(config.lora_adapter_path, "adapter_config.json")
        
        if os.path.exists(adapter_config_file):
            # LoRA Adapter 模式
            log_print(f"✓ 檢測到 LoRA Adapter（找到 adapter_config.json）")
            log_print(f"📦 載入基礎模型: {config.base_model_path}")
            
            model, tokenizer = FastLanguageModel.from_pretrained(
                model_name=config.base_model_path,
                max_seq_length=config.max_seq_length,
                dtype=None,
                load_in_4bit=False,
            )
            log_print("✓ 基礎模型載入完成")
            
            # 載入 LoRA adapter
            log_print(f"🔧 載入 LoRA adapter: {config.lora_adapter_path}")
            from peft import PeftModel
            model = PeftModel.from_pretrained(model, config.lora_adapter_path)
            log_print("✓ LoRA adapter 載入完成")
            
        else:
            # 合併模型模式（沒有 adapter_config.json）
            log_print(f"✓ 檢測到合併模型（沒有 adapter_config.json）")
            log_print(f"📦 直接載入合併模型: {config.lora_adapter_path}")
            
            model, tokenizer = FastLanguageModel.from_pretrained(
                model_name=config.lora_adapter_path,
                max_seq_length=config.max_seq_length,
                dtype=None,
                load_in_4bit=False,
            )
            log_print("✓ 合併模型載入完成")
        
        # 設置為推理模式
        FastLanguageModel.for_inference(model)
        model.eval()
        log_print("✓ 模型已設置為推理模式")
        
    except Exception as e:
        log_print(f"❌ 模型載入失敗: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
    
    print()
    
    # ============================================================
    # 2. 載入測試數據
    # ============================================================
    print("=" * 70)
    print("步驟 2: 載入測試數據")
    print("=" * 70)
    
    try:
        test_dataset = get_questions(split="test")
        
        # 限制測試樣本數
        if config.num_test_samples is not None:
            original_size = len(test_dataset)
            test_dataset = test_dataset.select(range(min(config.num_test_samples, len(test_dataset))))
            log_print(f"✓ 測試樣本數限制: {len(test_dataset)}/{original_size}")
        else:
            log_print(f"✓ 測試全部樣本: {len(test_dataset)}")
            
    except Exception as e:
        log_print(f"❌ 測試數據載入失敗: {e}")
        sys.exit(1)
    
    print()
    
    # ============================================================
    # 3. 進行測試
    # ============================================================
    print("=" * 70)
    print("步驟 3: 生成答案")
    print("=" * 70)
    print()
    
    results = []
    
    count=0
    accuracy_rate=0
    for idx in tqdm(range(len(test_dataset)), desc="生成答案"):
        sample = test_dataset[idx]
        
        try:
            # 準備輸入
            messages = sample['prompt']
            input_text = tokenizer.apply_chat_template(
                messages,
                tokenize=False,
                add_generation_prompt=True
            )
            
            inputs = tokenizer(input_text, return_tensors="pt").to(model.device)
            
            # 生成答案
            with torch.no_grad():
                outputs = model.generate(
                    **inputs,
                    max_new_tokens=config.max_new_tokens,
                    temperature=config.temperature,
                    top_p=config.top_p,
                    do_sample=config.do_sample,
                    pad_token_id=tokenizer.pad_token_id,
                    eos_token_id=tokenizer.eos_token_id,
                )
            
            # 解碼生成的答案
            generated_ids = outputs[0][inputs['input_ids'].shape[1]:]
            predicted_answer = tokenizer.decode(generated_ids, skip_special_tokens=True)
            
            # 儲存結果
            result = {
                'id': sample['id'],
                'question': sample['question'],
                'instruction': sample['instruction'],
                'ground_truth': sample['answer'],
                'predicted_answer': predicted_answer
            }
            results.append(result)
            
            if idx < len(test_dataset):
                anwser=sample['answer'][:-5]
                anwser=anwser[1:]
                if anwser in predicted_answer:
                    count=count+1
                else:
                    count=count
                print(f"\n{'='*70}")
                print(f"樣本 {idx+1}/{len(test_dataset)}")
                print(f"準確率 {count}/{idx}")
                print(f"{'='*70}")
                print(f"📋 ID: {sample['id']}")
                log_print(f"  {sample['question'][:200]}...")
                log_print(f"  \n🤖 模型預測答案:{predicted_answer[:500]}...")
                log_print(f"  \n✅ 真實答案:{sample['answer'][:-5]}...")
                print()
            accuracy_rate = (count / len(test_dataset)) * 100
            log_print(f"準確率 {accuracy_rate:.2f}%")
        except Exception as e:
            log_print(f"⚠️  樣本 {idx} 生成失敗: {e}")
            results.append({
                'id': sample['id'],
                'question': sample['question'],
                'ground_truth': sample['answer'],
                'predicted_answer': f"[ERROR] {str(e)}"
                'accuracy_rate': f"{accuracy_rate:.2f}%"
            })

    print()
    print("=" * 70)
    print("✓ 答案生成完成")
    print("=" * 70)
    print()
    

    # ============================================================
    # 4. 保存結果
    # ============================================================
    print("=" * 70)
    print("步驟 4: 保存測試結果")
    print("=" * 70)
    
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    
    # 保存為 JSON
    output_file = os.path.join(config.output_dir, f"test_results_{timestamp}.json")
    with open(output_file, 'w', encoding='utf-8') as f:
        json.dump(results, f, ensure_ascii=False, indent=2)
    log_print(f"✓ 結果已保存到: {output_file}")
    
    # 保存為可讀文本
    output_txt = os.path.join(config.output_dir, f"test_results_{timestamp}.txt")
    with open(output_txt, 'w', encoding='utf-8') as f:
        for i, result in enumerate(results, 1):
            f.write(f"{'='*70}\n")
            f.write(f"樣本 {i}/{len(results)}\n")
            f.write(f"{'='*70}\n")
            f.write(f"ID: {result['id']}\n\n")
            f.write(f"問題:\n{result['question']}\n\n")
            f.write(f"模型預測答案:\n{result['predicted_answer']}\n\n")
            f.write(f"真實答案:\n{result['ground_truth']}\n\n")
            f.write("\n")
    log_print(f"✓ 可讀文本已保存到: {output_txt}")
    
    print()
    print("=" * 70)
    print("🎉 測試完成！")
    print("=" * 70)
    print(f"✓ 測試樣本數: {len(results)}")
    print(f"✓ 結果文件: {output_file}")
    print(f"✓ 文本文件: {output_txt}")
    print("=" * 70)

# ============================================================
# 命令行接口
# ============================================================
def main():
    parser = argparse.ArgumentParser(description="測試 GRPO 訓練的模型（支持合併模型或 LoRA adapter）")
    parser.add_argument(
        "--base_model", 
        type=str, 
        default="/content/Colab_Download/Qwen2.5-3B-Instruct",
        help="基礎模型路徑（僅在使用 LoRA adapter 時需要）"
    )
    parser.add_argument(
        "--lora_adapter", 
        type=str, 
        default="/content/merged_model",
        help="合併模型或 LoRA adapter 路徑（腳本會自動檢測）"
    )
    parser.add_argument(
        "--test_data", 
        type=str, 
        default="/content/test_data.json",
        help="測試數據路徑"
    )
    parser.add_argument(
        "--output_dir", 
        type=str, 
        default="/content/Colab/test_results",
        help="輸出目錄"
    )
    parser.add_argument(
        "--num_samples", 
        type=int, 
        default=None,
        help="測試樣本數（None 表示全部）"
    )
    parser.add_argument(
        "--temperature", 
        type=float, 
        default=0.7,
        help="生成溫度"
    )
    
    args = parser.parse_args()
    
    # 更新配置
    config = TestConfig()
    config.base_model_path = args.base_model
    config.lora_adapter_path = args.lora_adapter
    config.test_data = args.test_data
    config.output_dir = args.output_dir
    config.num_test_samples = args.num_samples
    config.temperature = args.temperature
    
    # 執行測試
    test_model(config)

if __name__ == "__main__":
    main()

