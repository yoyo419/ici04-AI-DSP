#!/usr/bin/env python3
"""
⚡ 快速推論測試（簡化版）
最簡單的模型測試方式
"""

import torch
from transformers import AutoModelForCausalLM, AutoTokenizer

print("=" * 70)
print("⚡ Legal Delta 快速測試")
print("=" * 70)
print()

# ============================================================
# 配置
# ============================================================
MODEL_PATH = "/content/Colab/merged_model"  # 修改為你的模型路徑
DEVICE = "auto"  # auto/cuda/cpu

# ============================================================
# 載入模型
# ============================================================
print("📝 載入 tokenizer...")
tokenizer = AutoTokenizer.from_pretrained(MODEL_PATH, trust_remote_code=True)

print("🧠 載入模型...")
if torch.cuda.is_available():
    print(f"   ✓ GPU: {torch.cuda.get_device_name(0)}")
    model = AutoModelForCausalLM.from_pretrained(
        MODEL_PATH,
        torch_dtype=torch.float16,
        device_map="auto",
        trust_remote_code=True
    )
else:
    print("   ⚠️  使用 CPU（較慢）")
    model = AutoModelForCausalLM.from_pretrained(
        MODEL_PATH,
        torch_dtype=torch.float32,
        trust_remote_code=True
    )

print("   ✓ 模型載入完成")
print()

# ============================================================
# 測試問題
# ============================================================
test_question = """依勞動基準法規定，雇主延長勞工之工作時間連同正常工作時間，每日不得超過多少小時？

(1). 10
(2). 11
(3). 12
(4). 15

請按照以下格式回答：
<reasoning>
詳細分析問題並展示推理過程
</reasoning>
<answer>
提供最終答案
</answer>"""

print("=" * 70)
print("📝 測試問題：")
print("=" * 70)
print(test_question)
print()

# ============================================================
# 生成回答
# ============================================================
print("=" * 70)
print("💡 模型回答：")
print("=" * 70)

# 準備輸入
inputs = tokenizer(test_question, return_tensors="pt")
if torch.cuda.is_available():
    inputs = inputs.to("cuda")

# 生成
print("⏳ 生成中...")
import time
start_time = time.time()

with torch.no_grad():
    outputs = model.generate(
        **inputs,
        max_new_tokens=512,
        temperature=0.7,
        top_p=0.9,
        do_sample=True,
        pad_token_id=tokenizer.pad_token_id,
        eos_token_id=tokenizer.eos_token_id,
    )

elapsed = time.time() - start_time

# 解碼並顯示
response = tokenizer.decode(outputs[0], skip_special_tokens=True)
print(response)
print()

print("=" * 70)
print(f"⏱️  生成時間: {elapsed:.2f} 秒")
print("=" * 70)
print()

print("✅ 測試完成！")
print()
print("💡 提示：")
print("   • 如果回答合理，說明模型訓練成功")
print("   • 如果回答不完整，可以增加 max_new_tokens")
print("   • 如果回答太隨機，可以降低 temperature")
print()

