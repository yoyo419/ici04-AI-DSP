import re
import itertools
import numpy as np
import math
from typing import List
import torch

import cn2an


############################ format reward ##############################

# 原本這個空函式只有 docstring，為避免混淆，改為整段註解（不刪）
# def count_xml(text) -> float:
#     """
#     計算 XML 標籤的正確性得分
#     Args:
#         text: 模型输出文本
#     Returns:
#         float: 得分 (0.0 - 1.0)
#     """

TAG_REAS_OPEN  = re.compile(r'<\s*reasoning\s*>', re.I)
TAG_REAS_CLOSE = re.compile(r'<\s*/\s*reasoning\s*>', re.I)
TAG_ANS_OPEN   = re.compile(r'<\s*answer\s*>', re.I)
TAG_ANS_CLOSE  = re.compile(r'<\s*/\s*answer\s*>', re.I)
TAG_EOA        = re.compile(r'<\s*eo[as]\s*>', re.I)  # 支援 <eoa> 或 <eos>
BRACKET_ANY    = re.compile(r'\[(正确答案|正確答案)\]')

def count_xml(text) -> float:
    """
    計算 XML 標籤的正確性得分
    
    檢查項目：
    - <reasoning> 和 </reasoning> 標籤各出現 1 次 (各 0.125 分)
    - <answer> 和 </answer> 標籤各出現 1 次 (各 0.125 分)
    - [正確答案] 或 [正确答案] 出現 (0.125 分)
    - <eoa> 或 <eos> 出現至少 1 次 (0.125 分)
    - 推理和答案區塊都有內容且包含 <eoa> (0.25 分)
    - 扣分項：<eoa>/<eos> 後有多餘內容 (每字元 -0.01，最多 -0.375)
    
    Args:
        text: 模型生成的回答文本
    
    Returns:
        float: 格式得分 (0.0 - 1.0)
    """
    score = 0.0

    if len(TAG_REAS_OPEN.findall(text)) == 1:
        score += 0.125
    if len(TAG_REAS_CLOSE.findall(text)) == 1:
        score += 0.125
    if len(TAG_ANS_OPEN.findall(text)) == 1:
        score += 0.125
    if len(TAG_ANS_CLOSE.findall(text)) == 1:
        score += 0.125

    if BRACKET_ANY.search(text):
        score += 0.125

    if len(TAG_EOA.findall(text)) >= 1:
        score += 0.125
        # 結尾多餘內容扣分：以最後一個 <eoa>/<eos> 為準
        last = None
        for m in TAG_EOA.finditer(text):
            last = m
        if last:
            tail = text[last.end():]
            penalty = len(tail.strip()) * 0.01
            score -= min(penalty, 0.375)

    # 推理＋答案都有內容再加分
    try:
        reasoning = re.search(r'<\s*reasoning\s*>(.*?)<\s*/\s*reasoning\s*>', text, re.S|re.I)
        answer   = re.search(r'<\s*answer\s*>(.*?)<\s*/\s*answer\s*>', text, re.S|re.I)
        if reasoning and reasoning.group(1).strip() and answer and answer.group(1).strip() and TAG_EOA.search(answer.group(1)):
            score += 0.25
    except Exception:
        pass

    return score


def xmlcount_reward_func(completions, **kwargs) -> list[float]:
    """
    XML 格式檢查獎勵函數
    
    檢查生成內容中的 XML 標籤完整性（<reasoning>, <answer>, <eoa> 等）
    
    Args:
        completions: 模型生成的回覆列表，格式為
            [
                [{"role": "assistant", "content": "..."}],
                ...
            ]
        **kwargs: 其他參數
    
    Returns:
        List[float]: 格式分數列表，範圍 0.0-1.0
    """
    contents = [completion[0]["content"] for completion in completions]
    scores = [count_xml(c) for c in contents]
    for i, score in enumerate(scores):
        print(f"內容 {i+1} XML格式分數: {score:.3f}")
    return scores

def extract_correct_option(text):
    """
    從文本中提取正確選項（用於選擇題評分）
    
    支援格式：
    - [正確答案]1<eoa> 或 [正确答案]2<eos>
    - [正確答案](3)<eoa> 或 [正确答案]（4）<eoa>
    
    Args:
        text: 模型生成的回答文本
    
    Returns:
        str or None: 提取的選項編號 (1-5)，若未找到則返回 None
    """
    pattern = r'\[(正确答案|正確答案)\](.*?)<\s*eo[as]\s*>'
    match = re.search(pattern, text, re.DOTALL)
    if not match:
        return None
    content = match.group(2).strip()
    m = re.search(r'\b([1-5])\b', content)
    if not m:
        m = re.search(r'[（(]([1-5])[)）]', content)
    return m.group(1) if m else None

def scoring_function(prompts, completions, answer, **kwargs):
    """
    選擇題專用評分函數
    只評估多選題（[正确答案]/[正確答案]），其他任務暫停（註解保留）。
    
    Args:
        prompts: 提示列表，格式為對話訊息列表
            [
                [{"role": "user", "content": "..."}, {"role": "assistant", "content": "..."}],
                ...
            ]
        completions: 模型生成的回覆列表，格式為
            [
                [{"role": "assistant", "content": "..."}],  # completion 1
                [{"role": "assistant", "content": "..."}],  # completion 2
                ...
            ]
        answer: 正確答案列表 (字符串)
        **kwargs: 其他參數（如數據集中的其他欄位）
    
    Returns:
        List[float]: 評分列表，每個分數範圍 0.0-5.0
    """
    print("[DEBUG-REWARD] ===== 進入選擇題專用評分模式 =====")
    print(f"[DEBUG-REWARD] 收到 {len(prompts)} 個提示和 {len(completions)} 個回覆")

    # 收集 user 指令 & 模型回覆
    responses, instructions = [], []
    for prompt, completion in zip(prompts, completions):
        instr = ""
        for msg in prompt:
            if msg.get("role") == "user":
                instr = msg.get("content", "")
                break
        instructions.append(instr)
        responses.append(completion[0]['content'])

    all_scores = []
    for idx, (instruction, response) in enumerate(zip(instructions, responses)):
        print(f"\n[DEBUG-REWARD] 評估第 {idx+1} 個回覆 (選擇題模式)...")
        gold = answer[idx] if idx < len(answer) else answer[0]

        # 只做選擇題抽取與比對
        pred_opt = extract_correct_option(response)
        gold_opt = extract_correct_option(gold)
        print(f"正確選項: {gold_opt}")
        print(f"提取的選項: {pred_opt}")

        if pred_opt is None or gold_opt is None:
            score = 0.0
        elif pred_opt == gold_opt:
            score = 5.0
        else:
            score = 0.0

        all_scores.append(score)
        print(f"[DEBUG-REWARD] 多選題評分: {score:.3f}")

    print(f"\n所有選擇題評分: {[round(s, 3) for s in all_scores]}")
    return all_scores


############################ info-gain bonus（保留，作用於 MCQ 分數） ############################

def calculate_answer_diversity_bonus_v2(answer_token_info, baseline_answer_info, base_score):
    """
    計算資訊增益獎勵係數
    
    透過比較推理回答和直接回答的 logit 差異，獎勵有充分推理的回答。
    
    Args:
        answer_token_info: 推理回答的 token 統計資訊
            {"avg_logit": float, ...}
        baseline_answer_info: 基準回答的 token 統計資訊
            {"avg_logit": float, ...}
        base_score: 基礎分數 (0.0-5.0)
    
    Returns:
        float: 增強後的分數
        
    計算公式：
        info_gain = reasoning_logit - direct_logit
        info_gain_factor = sigmoid(info_gain / 5)
        enhanced_score = base_score * info_gain_factor
    """
    if not answer_token_info or 'avg_logit' not in answer_token_info:
        print("[INFO_GAIN] answer_token_info無效，使用原始分數")
        return base_score
    if not baseline_answer_info or 'avg_logit' not in baseline_answer_info:
        print("[INFO_GAIN] baseline_answer_info無效，使用原始分數")
        return base_score
    reasoning_logit = answer_token_info['avg_logit']
    direct_logit = baseline_answer_info['avg_logit']
    info_gain = reasoning_logit - direct_logit
    print(f"[INFO_GAIN] reasoning_logit={reasoning_logit:.4f}, direct_logit={direct_logit:.4f}, info_gain={info_gain:.4f}")
    info_gain_factor = torch.sigmoid(torch.tensor(info_gain/5)).item()
    print(f"[INFO_GAIN] info_gain_factor={info_gain_factor:.3f}")
    enhanced_score = base_score * info_gain_factor
    print(f"[INFO_GAIN] base_score={base_score:.3f}, info_gain_factor={info_gain_factor:.3f}, enhanced_score={enhanced_score:.3f}")
    return enhanced_score

def enhanced_scoring_function_v2(prompts, completions, answer,
                                 answer_token_info=None, baseline_answer_info=None, **kwargs):
    """
    增強版選擇題評分函數（支援資訊增益獎勵）
    
    先用基礎 scoring_function 計算分數，若提供 token 資訊，再乘上 info-gain 係數。
    
    Args:
        prompts: 提示列表，格式為對話訊息列表
            [
                [{"role": "user", "content": "..."}, ...],
                ...
            ]
        completions: 模型生成的回覆列表，格式為
            [
                [{"role": "assistant", "content": "..."}],
                ...
            ]
        answer: 正確答案列表 (字符串)
        answer_token_info: (可選) 推理回答的 token 統計資訊列表
            [
                {"avg_logit": float, ...},
                ...
            ]
        baseline_answer_info: (可選) 基準回答的 token 統計資訊列表
            格式同 answer_token_info
        **kwargs: 其他參數
    
    Returns:
        List[float]: 增強後的評分列表，範圍 0.0-5.0
        
    Note:
        - 如果 answer_token_info 和 baseline_answer_info 都提供，則使用資訊增益機制
        - 否則直接返回基礎分數
    """
    print("[DEBUG-REWARD] ===== 進入增強選擇題評分函數 =====")
    base_scores = scoring_function(prompts, completions, answer, **kwargs)
    enhanced_scores = []
    for i, base_score in enumerate(base_scores):
        current_answer_info = answer_token_info[i] if (answer_token_info and i < len(answer_token_info)) else None
        current_baseline_info = baseline_answer_info[i] if (baseline_answer_info and i < len(baseline_answer_info)) else None
        if current_answer_info and current_baseline_info:
            enhanced_score = calculate_answer_diversity_bonus_v2(
                current_answer_info,
                current_baseline_info,
                base_score
            )
            print(f"[DEBUG-REWARD] 樣本{i+1}: 使用增益，基礎分數={base_score:.3f}, 增強分數={enhanced_score:.3f}")
        else:
            enhanced_score = base_score
            print(f"[DEBUG-REWARD] 樣本{i+1}: 缺少token，使用基礎分數={base_score:.3f}")
        enhanced_scores.append(enhanced_score)

    # 可選記錄
    try:
        import swanlab
        swanlab.log({
            "reward/mcq_base_score": np.mean(base_scores),
            "reward/mcq_enhanced_score": np.mean(enhanced_scores),
        })
    except:
        pass

    return enhanced_scores
