#!/usr/bin/env python3
# ========================================
# 簡易模型測試腳本（職業安全衛生版）
# quick_test_osh.py
# ========================================

import torch
from transformers import AutoModelForCausalLM, AutoTokenizer

print("🧪 載入模型...")

# 1. 載入模型
model_path = "/content/Colab/merged_model"
tokenizer = AutoTokenizer.from_pretrained(model_path, trust_remote_code=True)
model = AutoModelForCausalLM.from_pretrained(
    model_path,
    torch_dtype=torch.float16,
    device_map="auto",
    trust_remote_code=True,
)
model.eval()

print("✓ 模型載入完成\n")

# 2. 系統提示詞
SYSTEM_PROMPT = """用户与助手之间的对话。用户提出问题，助手解决它。助手首先思考推理过程，然后提供用户答案。推理过程和答案分别包含在 <reasoning> </reasoning> 和 <answer> </answer> 标签中。

请按照以下格式回答问题：
<reasoning>
在此详细分析问题并展示完整的推理过程，包括思考步骤、相关知识和逻辑分析。
</reasoning>
<answer>
在此提供简洁明确的最终答案。
</answer>"""

TASK_INSTRUCTION = """**任務描述：**

你是一個職業安全衛生專家，請你運用專業知識分析下列問題並回答相關問題。

**輸入：**

- 職業安全衛生問題及選項

**輸出格式：**

請按照以下格式輸出你的分析結果：

```
<reasoning>
{詳細分析過程}
</reasoning>
<answer>
[正確答案]{選項數字}<eoa>
</answer>
```

- `{詳細分析過程}`：包含你對職業安全衛生問題的分析過程，詳細解釋為什麼選擇特定選項作為答案。
- `{選項數字}`：表示你認為正確的選項數字，如1、2、3、4。
- `[正確答案]`：表示答案輸出開始的標誌。
- `<eoa>`：表示輸出結束的標誌。
輸入：
"""

# 3. 定義生成函數
def ask(question, use_instruction=True, max_length=512, show_details=True):
    """
    向模型提問並顯示推理過程
    
    Args:
        question: 你的問題
        use_instruction: 是否使用完整的任務指令
        max_length: 最大生成長度
        show_details: 是否顯示詳細的推理過程和答案（預設 True）
    
    Returns:
        模型的回答（原始文本）
    """
    import re
    
    if use_instruction:
        # 使用完整格式（適合選擇題）
        prompt = f"{SYSTEM_PROMPT}\n\n你是一個職業安全衛生專家，請按照以下要求回答：\n{TASK_INSTRUCTION}\n\n{question}"
    else:
        # 簡單格式（適合一般問答）
        prompt = f"{SYSTEM_PROMPT}\n\n你是一個職業安全衛生專家，請回答以下問題：\n\n{question}"
    
    inputs = tokenizer(prompt, return_tensors="pt").to(model.device)
    
    with torch.no_grad():
        outputs = model.generate(
            **inputs,
            max_new_tokens=max_length,
            temperature=0.7,
            top_p=0.9,
            do_sample=True,
            pad_token_id=tokenizer.pad_token_id,
            eos_token_id=tokenizer.eos_token_id,
        )
    
    response = tokenizer.decode(
        outputs[0][inputs.input_ids.shape[1]:], 
        skip_special_tokens=True
    )
    
    # 如果需要顯示詳細資訊，解析並印出推理過程和答案
    if show_details:
        # 提取 <reasoning> 部分
        reasoning_match = re.search(r'<reasoning>(.*?)</reasoning>', response, re.DOTALL)
        # 提取 <answer> 部分
        answer_match = re.search(r'<answer>(.*?)</answer>', response, re.DOTALL)
        
        if reasoning_match:
            reasoning = reasoning_match.group(1).strip()
            print("🧠 推理過程:")
            print("-" * 70)
            print(reasoning)
            print()
        
        if answer_match:
            answer = answer_match.group(1).strip()
            print("✅ 最終答案:")
            print("-" * 70)
            print(answer)
        
        # 如果沒有找到標準格式，直接顯示原始回應
        if not reasoning_match and not answer_match:
            print("📝 模型回答:")
            print("-" * 70)
            print(response)
    
    return response

# 4. 測試範例
print("=" * 70)
print("📝 測試範例")
print("=" * 70)
print()

# 範例 1：選擇題（使用完整指令）
question1 = """下列何者屬於職業安全衛生法規定的危險性機械？

1. 堆高機
2. 固定式起重機
3. 手推車
4. 電動推車
"""

print("【範例 1】選擇題")
print("-" * 70)
print("問題:")
print(question1)
print("\n模型回答:")
print(ask(question1, use_instruction=True))
print("\n" + "=" * 70 + "\n")

# 範例 2：簡單問答（不使用完整指令）
question2 = "什麼是職業安全衛生管理系統？"

print("【範例 2】簡單問答")
print("-" * 70)
print("問題:")
print(question2)
print("\n模型回答:")
print(ask(question2, use_instruction=False, max_length=256))
print("\n" + "=" * 70 + "\n")

# 5. 互動模式
print("💬 互動模式 (輸入 'quit' 退出，輸入 'help' 查看幫助)")
print("=" * 70)
print()

while True:
    try:
        user_input = input("你的問題 >>> ")
        
        if user_input.lower() in ['quit', 'exit', 'q', '退出']:
            print("👋 再見！")
            break
        
        if user_input.lower() in ['help', '幫助', '说明']:
            print("""
使用說明：
  - 直接輸入問題即可（選擇題會自動使用完整格式）
  - 輸入 'quit' 或 'exit' 退出
  - 輸入 'help' 查看此說明

範例問題：
  1. 什麼是作業環境監測？
  2. 危險性工作場所的定義為何？
            """)
            continue
        
        if not user_input.strip():
            continue
        
        print("\n生成中...\n")
        
        # 自動判斷是否為選擇題（包含數字選項）
        is_multiple_choice = any(f"{i}." in user_input or f"({i})" in user_input for i in range(1, 6))
        
        answer = ask(user_input, use_instruction=is_multiple_choice)
        
        print("回答:")
        print(answer)
        print("\n" + "-" * 70 + "\n")
        
    except KeyboardInterrupt:
        print("\n\n👋 再見！")
        break
    except Exception as e:
        print(f"❌ 錯誤: {e}\n")

print("\n✓ 測試完成")

